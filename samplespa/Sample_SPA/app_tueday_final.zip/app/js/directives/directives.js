
eventsApp.directive('customInputField', function() {
  return {
    restrict: 'E',
    template: '<label for="{{id}}">{{name}}</label>'+
               '<input id={{id}} type="text" placeholder="{{name}}" ng-model="{{model}}" />',
    scope: {
        name:'@',
        id:'@',
        model:'@'
    },
    replace:true
  };
});