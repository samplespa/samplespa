
eventsApp.controller('WorkInfoController', function($scope){

    console.log("WorkInfoController");
     $scope.selectedIndex = 2;



});