'use strict';

var eventsApp = angular.module('eventsApp', ['ngRoute']);
eventsApp.config(function($routeProvider) {

    $routeProvider.when("/personalInfo", {
        templateUrl:"template/PersonalInfo.html",
        controller: 'PersonalInfoController'
    });

    $routeProvider.when("/workInfo", {
        templateUrl:"template/WorkInfo.html",
        controller: 'WorkInfoController'
    });

    $routeProvider.when("/travelDoc", {
        templateUrl:"template/TravelDoc.html",
        controller: 'TravelDocController'
    });

    $routeProvider.when("/docs", {
        templateUrl:"template/Docs.html",
        controller: 'DocsController'
    });

    $routeProvider.when("/summary", {
        templateUrl:"template/Summary.html",
        controller: 'SummaryController'
    });

});

//eventsApp.controller('EditEventController', function(){
//
//
//});
//eventsApp.directive('simpleDirective', function(){
//    return {
//
//        restrict:"AE",
//        template:"<div> <h1>Outer</h1> <input ng-model='model.jiju'> <div ng-transclude></div> </div>",
//        transclude:true,
////        replace:true,
//        link:function(){
//            console.log("link parent");
//        },
//        controller:function($scope){
//            console.log("controller parent");
//            $scope.model = {jiju:"jijukjose"};
//        }
//    }
//});
//
//
//eventsApp.directive('simpleInnerDirective', function(){
//    return {
//
//        restrict:"AE",
//        template:"<div><h2>Inner</h2><input ng-model='jiju'/></div>",
////        replace:true,
//        scope:{
//            jiju:"="
//        },
//        link:function(){
//            console.log("link child");
//        },
//        controller:function($scope){
//            console.log("controller child");
//            console.log("controller child: "+$scope.jiju);
//        }
//    }
//});
//eventsApp.directive('ngCity', function() {
//  return {
//    controller: function($scope) {}
//  }
//});
//eventsApp.directive('ngSparkline', function() {
//  return {
//    restrict: 'A',
//    require: '^ngCity',
//    scope: {
//      ngCity: '@'
//    },
//    transclude:true,
//     template: '<div class="sparkline"><h4>Weather for {{ngCity}}</h4><div ng-transclude></div></div>',
//    controller: ['$scope', '$http', function($scope, $http) {
//
//
////    chart.series.data =
//          var url = "http://api.openweathermap.org/data/2.5/forecast/daily?mode=json&units=imperial&cnt=7&callback=JSON_CALLBACK&q="
//
//          $scope.getTemp = function(city) {
//            var promise= $http({
//              method: 'JSONP',
//              url: url + city
//            }).success(function(data) {
//                var weather = [];
//                angular.forEach(data.list, function(value){
//                    weather.push(value);
//                });
//                $scope.weather = weather;
//            });
//            return promise;
//          };
//        }],
//        link: function(scope, iElement, iAttrs, ctrl) {
//            var width   = iAttrs.width || 200,
//            height  = iAttrs.height || 80;
//         var prmomise = scope.getTemp(iAttrs.ngCity);
//               scope.$watch('weather', function(newVal) {
//                 // the `$watch` function will fire even if the
//                 // weather property is undefined, so we'll
//                 // check for it
//                 if (newVal) {
//                   var highs = [],
//                       width   = 200,
//                       height  = 80;
//
//                   angular.forEach(scope.weather, function(value){
//                     highs.push(value.temp.max);
//                   });
//                   var chart = chartGraph(iElement, highs, iAttrs);
//                   chart.series.data =[29.9, 71.5, 106.4, 129.2, 144.0, 176.0, 135.6, 148.5, 216.4, 194.1, 95.6, 54.4];
//                   // chart
//                 }
//               });
//        }
//  }
//});
//var chartGraph = function(element, data, opts) {
//// $(function () {
//         return $('#container').highcharts({
//             title: {
//                 text: 'Chart reflow is set to true'
//             },
//
//             subtitle: {
//                 text: 'When resizing the window or the frame, the chart should resize'
//             },
//
//
//             xAxis: {
//                 categories: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
//             },
//
//             series: [{
//                 data: null
//             }]
////         });
//     });
//}
