
eventsApp.controller('TravelDocController', function($scope){

    console.log("TravelDocController")
     $scope.selectedIndex = 3;
});