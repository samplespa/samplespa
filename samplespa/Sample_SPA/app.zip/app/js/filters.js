'use strict';
eventsApp.filter('duration',function() {
    return function(duration/*input*/){
        switch (duration) {
            case 1:
                return "jiju1";
            break;
            case 2:
                return "jiju2";
            break;
            case 3:
                return "jiju3";
            break;
        }
    }
})

