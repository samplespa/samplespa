
eventsApp.controller('PersonalInfoController', function($scope){
    console.log("PersonalInfoController")
    $scope.selectedIndex = 1;
});