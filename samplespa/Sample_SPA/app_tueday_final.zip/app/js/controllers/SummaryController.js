
eventsApp.controller('SummaryController', function(){

    console.log("SummaryController")
});