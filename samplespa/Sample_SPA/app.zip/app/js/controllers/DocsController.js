
eventsApp.controller('DocsController', function($scope){

    console.log("DocsController");
     $scope.selectedIndex = 4;
});