
eventsApp.controller('ParentController', function($scope){

    $scope.select=function(index) {
        $scope.selectedIndex = index;
    }
    $scope.user={};
});